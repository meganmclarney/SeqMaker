#!/bin/bash

# STOP-SeqMaker.command
# Double-click this to stop SeqMaker

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "================================================"
echo "🛑 Stopping SeqMaker..."
echo "================================================"
echo ""

# Check if PID file exists
if [ ! -f ".seqmaker.pid" ]; then
    echo "⚠️  SeqMaker doesn't appear to be running"
    echo "(no .seqmaker.pid file found)"
    echo ""
    read -p "Press Enter to close..."
    exit 0
fi

# Read the PID
PID=$(cat .seqmaker.pid)

# Check if process is actually running
if ! ps -p $PID > /dev/null 2>&1; then
    echo "⚠️  SeqMaker process not found (PID: $PID)"
    echo "It may have already stopped."
    rm -f .seqmaker.pid
    echo ""
    read -p "Press Enter to close..."
    exit 0
fi

# Stop the process gracefully
echo "Stopping SeqMaker (PID: $PID)..."
kill $PID 2>/dev/null

# Wait a moment for graceful shutdown
sleep 2

# Check if it stopped
if ps -p $PID > /dev/null 2>&1; then
    echo "Process still running, forcing shutdown..."
    kill -9 $PID 2>/dev/null
    sleep 1
fi

# Clean up PID file
rm -f .seqmaker.pid

# Clean up any lock files
rm -f .locks/*.lock 2>/dev/null

echo ""
echo "✓ SeqMaker has been stopped"
echo ""
echo "You can now:"
echo "  • Check your processed videos in the 'done' folder"
echo "  • View extracted frames in the video name folders"
echo "  • Add more videos and click START-SeqMaker again"
echo ""
read -p "Press Enter to close..."
