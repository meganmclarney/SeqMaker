# Copyright Metadata in SeqMaker

## What Gets Added

Every JPEG frame extracted by SeqMaker now includes embedded copyright metadata:

- **Artist**: Megan McLarney
- **Copyright**: Copyright © [YEAR] Megan McLarney. All Rights Reserved.
- **Copyright Notice**: Copyright © [YEAR] Megan McLarney. All Rights Reserved.
- **Rights**: Copyright © [YEAR] Megan McLarney. All Rights Reserved.
- **Creator**: Megan McLarney

The year is automatically set to the current year when the frames are extracted.

## How to View Metadata

### On Mac (Finder):
1. Right-click any JPEG frame
2. Select "Get Info"
3. Look under "More Info" section
4. You'll see Artist, Copyright, etc.

### Using Command Line:
```bash
exiftool frame_000001.jpg
```

### In Photoshop/Lightroom:
1. Open the image
2. File → File Info
3. Check the Description and IPTC tabs
4. You'll see all copyright information

## Legal Format

The copyright notice follows proper legal format:
```
Copyright © 2026 Megan McLarney. All Rights Reserved.
```

This includes:
- ✓ Copyright symbol (©)
- ✓ Year of creation
- ✓ Copyright holder name
- ✓ "All Rights Reserved" statement

## Requirements

SeqMaker uses **exiftool** to add metadata. This should be pre-installed on most Macs, but if you get an error about exiftool not being found:

### Install exiftool:
```bash
brew install exiftool
```

Or download from: https://exiftool.org

## Verification

To verify copyright was added to your frames:

```bash
# Check a single frame
exiftool frame_000001.jpg | grep Copyright

# Check all frames in a folder
exiftool -Copyright -Artist 1fps_189/*.jpg
```

You should see:
```
Artist                          : Megan McLarney
Copyright                       : Copyright © 2026 Megan McLarney. All Rights Reserved.
Copyright Notice                : Copyright © 2026 Megan McLarney. All Rights Reserved.
```

## Impact on File Size

Metadata adds minimal size (typically less than 1KB per image), so your JPEG files remain lightweight.

## Social Media & Web

When you upload these frames to:
- **Instagram**: Copyright info is preserved in the file
- **Twitter/X**: Copyright info is preserved in the file  
- **Stock photo sites**: Metadata is retained and searchable
- **Your website**: Copyright info travels with the image

This helps protect your work and makes it clear who owns the copyright!

## Note

The copyright metadata is embedded during frame extraction. If you need to change the copyright information on existing frames:

```bash
# Update copyright on existing frames
exiftool -overwrite_original \
    -Artist="New Name" \
    -Copyright="Copyright © 2026 New Name. All Rights Reserved." \
    *.jpg
```

---

Your frames are now copyright-protected! 🔒✨
