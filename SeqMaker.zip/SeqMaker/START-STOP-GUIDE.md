# SeqMaker - Start/Stop Workflow Guide

## 🎯 Simple Workflow

### Step 1: Prepare
1. Copy your video files (.mov, .mp4) into the SeqMaker folder
2. Wait for all files to finish copying

### Step 2: Start Processing
Double-click: **START-SeqMaker.command**
- A Terminal window will open
- SeqMaker will begin processing your videos
- Leave the Terminal window open!

### Step 3: Wait for Processing
- Watch the Terminal window for progress
- Videos will be processed one by one
- Completed videos move to the `done/` folder
- Extracted frames appear in folders named after each video

### Step 4: Stop When Done
Double-click: **STOP-SeqMaker.command**
- This cleanly stops SeqMaker
- Safe to do even while processing (current video will finish)

### Step 5: Get Your Files
- **Processed videos**: Check the `done/` folder
- **Extracted frames**: Check the folders named after each video
  - Example: `myvideo/1fps_189/`, `myvideo/2fps_378/`, etc.

## 📁 Your Folder Structure

```
SeqMaker/
├── START-SeqMaker.command      ← Double-click to start
├── STOP-SeqMaker.command       ← Double-click to stop
├── SeqMaker-Portable.sh        (the main script)
│
├── 1fps/                       (empty marker folders)
├── 2fps/
├── 3fps/
├── 4fps/
├── 5fps/
│
├── myvideo.mov                 ← Drop your videos here
├── anothervideo.mov
│
├── done/                       ← Processed videos end up here
│   ├── myvideo.mov
│   └── anothervideo.mov
│
├── myvideo/                    ← Extracted frames here
│   ├── 1fps_189/
│   │   ├── frame_000001.jpg
│   │   ├── frame_000002.jpg
│   │   └── ...
│   ├── 2fps_378/
│   ├── 3fps_568/
│   ├── 4fps_757/
│   └── 5fps_947/
│
└── anothervideo/
    ├── 1fps_270/
    ├── 2fps_540/
    └── ...
```

## 💡 Tips

**Best Practice:**
1. Copy ALL videos FIRST
2. THEN click START-SeqMaker
3. Let it run until done
4. Click STOP-SeqMaker
5. Collect your frames!

**Multiple Batches:**
- Click STOP when done
- Copy new videos
- Click START again
- Repeat!

**Is SeqMaker Running?**
- If Terminal window is open → It's running
- If you see "SeqMaker is now watching" → It's running
- Click STOP to be sure

**Something Went Wrong?**
- Click STOP-SeqMaker
- Delete any incomplete folders
- Move videos back from `done/` if needed
- Click START-SeqMaker again

## 🚀 Quick Reference

| Action | File to Click |
|--------|---------------|
| Start processing | START-SeqMaker.command |
| Stop processing | STOP-SeqMaker.command |

## ⚙️ First Time Setup

1. Put these files in your SeqMaker folder:
   - START-SeqMaker.command
   - STOP-SeqMaker.command  
   - SeqMaker-Portable.sh

2. Make them executable (one time only):
   ```bash
   chmod +x START-SeqMaker.command
   chmod +x STOP-SeqMaker.command
   chmod +x SeqMaker-Portable.sh
   ```

3. Create fps folders you want:
   ```bash
   mkdir 1fps 2fps 3fps 4fps 5fps
   ```

Done! Now you can double-click to start and stop.

## 🎬 Working on External Drives

Works perfectly on external drives like Bunny04!

```
/Volumes/Bunny04/SeqMaker/
├── START-SeqMaker.command    ← Double-click here
├── STOP-SeqMaker.command
├── SeqMaker-Portable.sh
└── (rest of files...)
```

Same workflow:
1. Copy videos to `/Volumes/Bunny04/SeqMaker/`
2. Double-click START-SeqMaker.command
3. Wait for processing
4. Double-click STOP-SeqMaker.command
5. Done!

## 🔧 Troubleshooting

**"Permission denied" when clicking START**
```bash
chmod +x START-SeqMaker.command
```

**START doesn't open Terminal**
- Right-click → Open With → Terminal
- Or drag START-SeqMaker.command onto Terminal icon

**Can't find STOP button**
- Look for STOP-SeqMaker.command in the same folder as START
- You can also press Ctrl+C in the Terminal window

**Want to process more videos mid-run?**
- Just drop them in! SeqMaker will detect and process them
- No need to stop and restart

**Processed videos still in main folder?**
- Wait for processing to complete
- Videos move to `done/` automatically when finished
- If you stopped mid-process, they might still be there

---

Enjoy your frame-perfect video sequences! 🐰✨
