#!/bin/bash

# SeqMaker PORTABLE - Video to Image Sequence Converter
# Works from wherever you place it - internal drive or external drive
# Double-click this script to start processing videos in the same folder

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WATCH_DIR="$SCRIPT_DIR"
DONE_DIR="$WATCH_DIR/done"
LOCK_DIR="$WATCH_DIR/.locks"

# Create done folder and lock directory if they don't exist
mkdir -p "$DONE_DIR"
mkdir -p "$LOCK_DIR"

# Function to get video duration in seconds
get_duration() {
    ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "$1" | cut -d. -f1
}

# Function to check if file is locked
is_locked() {
    local video_file="$1"
    local base_name=$(basename "$video_file")
    local lock_file="$LOCK_DIR/$base_name.lock"
    [ -f "$lock_file" ]
}

# Function to create lock file
create_lock() {
    local video_file="$1"
    local base_name=$(basename "$video_file")
    local lock_file="$LOCK_DIR/$base_name.lock"
    touch "$lock_file"
}

# Function to remove lock file
remove_lock() {
    local video_file="$1"
    local base_name=$(basename "$video_file")
    local lock_file="$LOCK_DIR/$base_name.lock"
    rm -f "$lock_file"
}

# Function to wait for file to be stable (fully copied)
wait_for_stable_file() {
    local file_path="$1"
    local size1=$(stat -f%z "$file_path" 2>/dev/null || echo "0")
    sleep 3
    local size2=$(stat -f%z "$file_path" 2>/dev/null || echo "0")
    
    # If file size changed, it's still being written
    if [ "$size1" != "$size2" ]; then
        echo "Waiting for file to finish copying..."
        sleep 5
        wait_for_stable_file "$file_path"
    fi
}

# Function to process video file
process_video() {
    local video_file="$1"
    local base_name=$(basename "$video_file" | sed 's/\.[^.]*$//')
    local video_dir="$WATCH_DIR/$base_name"
    
    # Check if already being processed
    if is_locked "$video_file"; then
        return
    fi
    
    # Create lock file
    create_lock "$video_file"
    
    # Set up trap to prevent interruption during processing
    trap '' INT TERM
    
    echo "Processing: $video_file"
    
    # Get video duration for verification
    local duration=$(get_duration "$video_file")
    echo "Video duration: ${duration}s"
    
    # Create base directory for this video
    mkdir -p "$video_dir"
    
    # Process each FPS rate if the folder exists
    for fps in 1 2 3 4 5; do
        local fps_check_dir="$WATCH_DIR/${fps}fps"
        
        if [ -d "$fps_check_dir" ]; then
            echo "Converting at ${fps}fps..."
            
            # Create temporary output directory
            local temp_dir="$video_dir/temp_${fps}fps"
            mkdir -p "$temp_dir"
            
            # Extract frames using fps filter for accurate frame extraction
            # Run ffmpeg in a subshell to isolate it from signals
            # Redirect stderr to filter out deprecated warnings
            (
                trap '' INT TERM HUP
                ffmpeg -nostdin -i "$video_file" \
                    -vf "fps=${fps}" \
                    -q:v 2 \
                    "$temp_dir/frame_%06d.jpg" \
                    -y 2>&1 | grep -v "deprecated pixel format"
            ) &
            
            # Wait for ffmpeg to complete
            local ffmpeg_pid=$!
            wait $ffmpeg_pid
            
            # Count the actual number of frames extracted
            local frame_count=$(ls -1 "$temp_dir"/*.jpg 2>/dev/null | wc -l | tr -d ' ')
            
            if [ "$frame_count" -gt 0 ]; then
                # Add copyright metadata to all frames
                echo "Adding copyright metadata..."
                local year=$(date +%Y)
                exiftool -overwrite_original \
                    -Artist="Megan McLarney" \
                    -Copyright="Copyright © $year Megan McLarney. All Rights Reserved." \
                    -CopyrightNotice="Copyright © $year Megan McLarney. All Rights Reserved." \
                    -Rights="Copyright © $year Megan McLarney. All Rights Reserved." \
                    -Creator="Megan McLarney" \
                    "$temp_dir"/*.jpg 2>/dev/null
                
                # Rename directory with frame count
                local final_dir="$video_dir/${fps}fps_${frame_count}"
                mv "$temp_dir" "$final_dir"
                echo "✓ ${fps}fps: $frame_count frames extracted to $final_dir"
            else
                echo "✗ ${fps}fps: No frames extracted"
                rm -rf "$temp_dir"
            fi
        fi
    done
    
    # Move processed video to done folder
    echo "Moving video to done folder..."
    mv "$video_file" "$DONE_DIR/"
    
    # Remove lock file
    remove_lock "$video_file"
    
    # Restore signal handling
    trap - INT TERM
    
    echo "✓ Processing complete for $base_name"
    echo "----------------------------------------"
}

# Function to handle file events
handle_file() {
    local file_path="$1"
    
    # Check if file exists and is a video file
    if [ -f "$file_path" ]; then
        local lowercase_path=$(echo "$file_path" | tr '[:upper:]' '[:lower:]')
        case "$lowercase_path" in
            *.mov|*.mp4)
                # Skip if file is in done directory or is a lock file
                if [[ "$file_path" == *"/done/"* ]] || [[ "$file_path" == *"/.locks/"* ]]; then
                    return
                fi
                
                # Wait for file to be fully copied
                wait_for_stable_file "$file_path"
                
                # Only process if not already locked
                if ! is_locked "$file_path"; then
                    process_video "$file_path"
                fi
                ;;
        esac
    fi
}

# Display startup info
echo "========================================"
echo "SeqMaker PORTABLE"
echo "========================================"
echo "Working directory: $WATCH_DIR"
echo ""

# Check for existing video files and process them
echo "Checking for existing video files..."
for video in "$WATCH_DIR"/*.{mov,MOV,mp4,MP4}; do
    [ -e "$video" ] && handle_file "$video"
done

# Start watching for new files
echo ""
echo "SeqMaker is now watching: $WATCH_DIR"
echo "Monitoring for: .mov, .MOV, .mp4, .MP4"
echo "Press Ctrl+C to stop"
echo "----------------------------------------"

# Watch only the main directory, exclude subdirectories to avoid triggering on temp files
# Use more restrictive filters to only watch for video files in the root directory
fswatch -0 \
    --exclude='.*' \
    --include='\.mov$' \
    --include='\.MOV$' \
    --include='\.mp4$' \
    --include='\.MP4$' \
    --exclude='/[^/]+/' \
    "$WATCH_DIR" | while read -d "" event; do
    # Only process if event is in the root watch directory (not subdirectories)
    if [[ "$(dirname "$event")" == "$WATCH_DIR" ]]; then
        handle_file "$event"
    fi
done
