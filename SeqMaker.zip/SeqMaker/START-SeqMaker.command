#!/bin/bash

# START-SeqMaker.command
# Double-click this to start SeqMaker
# Put your video files in the folder BEFORE running this

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Check if SeqMaker is already running
if [ -f ".seqmaker.pid" ]; then
    PID=$(cat .seqmaker.pid)
    if ps -p $PID > /dev/null 2>&1; then
        echo "⚠️  SeqMaker is already running (PID: $PID)"
        echo "Click STOP-SeqMaker to stop it first."
        echo ""
        read -p "Press Enter to close..."
        exit 1
    else
        # Stale PID file, remove it
        rm -f .seqmaker.pid
    fi
fi

# Check if SeqMaker-Portable.sh exists
if [ ! -f "SeqMaker-Portable.sh" ]; then
    echo "❌ Error: SeqMaker-Portable.sh not found in this folder!"
    echo ""
    read -p "Press Enter to close..."
    exit 1
fi

# Make sure it's executable
chmod +x SeqMaker-Portable.sh

echo "================================================"
echo "🎬 Starting SeqMaker..."
echo "================================================"
echo ""
echo "Working in: $SCRIPT_DIR"
echo ""
echo "✓ SeqMaker is now running!"
echo "✓ Drop videos into this folder to process them"
echo "✓ Double-click STOP-SeqMaker when you're done"
echo ""
echo "This window will stay open while SeqMaker runs..."
echo "------------------------------------------------"
echo ""

# Start SeqMaker in the background and save its PID
./SeqMaker-Portable.sh &
SEQMAKER_PID=$!
echo $SEQMAKER_PID > .seqmaker.pid

# Wait for SeqMaker process
wait $SEQMAKER_PID

# Clean up PID file when done
rm -f .seqmaker.pid

echo ""
echo "SeqMaker has stopped."
read -p "Press Enter to close..."
